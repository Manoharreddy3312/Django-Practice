from django.shortcuts import render

# Create your views here.
def amazonpayhome(request):
    return render(request,'amazonpayhome.html')

