from django.apps import AppConfig


class AmazonpayConfig(AppConfig):
    name = 'Amazonpay'
