from django.apps import AppConfig


class MxplayerConfig(AppConfig):
    name = 'mxplayer'
